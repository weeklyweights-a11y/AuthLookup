To view the downloadable database (pdf) file(s), you will need Adobe Acrobat Reader installed. To download the latest version of Adobe Acrobat Reader (at no cost), please copy and paste the link below into your web browser's address bar.

This will take you to the Adobe web site where you can download a version of Acrobat Reader.

https://get.adobe.com/reader/

****************************************************************************************************

To view the downloadable database (mdb) file(s), you will need Microsoft Access Runtime installed. To download the latest version of Microsoft Access Runtime (at no cost), please copy and paste the link below into your web browser's address bar.

This will take you to the Microsoft web site where you can download a version of Microsoft Access Runtime.

https://www.microsoft.com/en-us/download/details.aspx?id=50040

****************************************************************************************************

To view the downloadable database (csv) file(s),  use a basic text editor like Notepad for simple viewing and basic edits. For a more structured approach, you can use a spreadsheet application like Google Sheets or LibreOffice Calc and import the CSV, which will parse the data into columns and rows, making it more readable. 

NOTE:  Some of the information within the .csv file(s) may contain HTML tags (e.g., : &#, #, <br>, <b>, <i>, <ul>, <li>). These HTML tags are intentionally included in the documents to affect how the text is displayed on a web page. Within the csv file, to help with parsing, the columns are delineated by commas, and the text qualifier is a double quote. When using screen reading software, please be aware of these characters when going through the data.